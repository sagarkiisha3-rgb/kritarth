import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MessageSquare, X } from 'lucide-react';

export const WhatsAppFloating: React.FC = () => {
  const { settings } = useApp();
  const [showTooltip, setShowTooltip] = useState(true);

  const whatsappMessage = encodeURIComponent(
    settings.whatsappPreFill || "Hello, I would like to book an appointment with Dr. Kritarth."
  );
  const cleanPhone = settings.whatsappNumber.replace(/[^0-9]/g, '');

  return (
    <div className="hidden sm:flex fixed bottom-6 right-6 z-40 flex-col items-end gap-2 pointer-events-auto">
      {/* Tooltip prompt */}
      {showTooltip && (
        <div className="bg-white rounded-2xl p-3 shadow-xl border border-slate-200 text-xs text-slate-700 max-w-[200px] relative animate-in fade-in slide-in-from-bottom-2 duration-300">
          <button
            onClick={() => setShowTooltip(false)}
            className="absolute -top-1.5 -left-1.5 w-5 h-5 rounded-full bg-slate-100 text-slate-400 hover:text-slate-700 flex items-center justify-center text-[10px]"
            title="Dismiss"
          >
            <X className="w-3 h-3" />
          </button>
          <div className="font-bold text-slate-900 mb-0.5">Quick OPD Help</div>
          <div>Need assistance scheduling with Dr. Kritarth? Chat on WhatsApp.</div>
        </div>
      )}

      {/* WhatsApp Button */}
      <a
        href={`https://wa.me/${cleanPhone}?text=${whatsappMessage}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp with Dr. Kritarth Clinic"
        className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 hover:scale-105 transition-all group"
      >
        <MessageSquare className="w-7 h-7 fill-white stroke-none" />
      </a>
    </div>
  );
};
