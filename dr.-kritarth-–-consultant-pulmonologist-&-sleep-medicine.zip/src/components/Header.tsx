import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import {
  Phone,
  Calendar,
  Menu,
  X,
  ChevronDown,
  Wind,
  ShieldCheck,
  ArrowRight,
  Activity,
  Microscope,
  Moon,
  AlertCircle,
  Stethoscope,
  HeartPulse,
  Sparkles
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    settings,
    activeRoute,
    selectedConditionSlug,
    navigate,
    openAppointmentModal
  } = useApp();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [conditionsDropdownOpen, setConditionsDropdownOpen] = useState(false);
  const [mobileConditionsExpanded, setMobileConditionsExpanded] = useState(false);
  const dropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Monitor scroll for navbar height & backdrop transition
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdown on outside click or escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setConditionsDropdownOpen(false);
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleMouseEnterDropdown = () => {
    if (dropdownTimeoutRef.current) {
      clearTimeout(dropdownTimeoutRef.current);
    }
    setConditionsDropdownOpen(true);
  };

  const handleMouseLeaveDropdown = () => {
    dropdownTimeoutRef.current = setTimeout(() => {
      setConditionsDropdownOpen(false);
    }, 150);
  };

  const handleNavClick = (route: string, param?: string) => {
    navigate(route, param);
    setMobileMenuOpen(false);
    setConditionsDropdownOpen(false);
  };

  // Respiratory condition list for dropdown
  const lungConditionsList = [
    {
      title: 'Asthma',
      desc: 'Allergies & airway hyperreactivity',
      slug: 'asthma',
      icon: Wind,
      color: 'text-teal-600 bg-teal-50',
    },
    {
      title: 'COPD',
      desc: 'Emphysema & chronic bronchitis rehab',
      slug: 'copd',
      icon: Activity,
      color: 'text-cyan-600 bg-cyan-50',
    },
    {
      title: 'Interstitial Lung Disease',
      desc: 'Pulmonary fibrosis & alveolar care',
      slug: 'interstitial-lung-disease',
      icon: Stethoscope,
      color: 'text-blue-600 bg-blue-50',
    },
    {
      title: 'Bronchiectasis',
      desc: 'Chronic bronchial clearance & infection control',
      slug: 'bronchiectasis',
      icon: HeartPulse,
      color: 'text-indigo-600 bg-indigo-50',
    },
    {
      title: 'Pulmonary Infections',
      desc: 'Pneumonia & bacterial/viral lung conditions',
      slug: 'pulmonary-infections',
      icon: AlertCircle,
      color: 'text-amber-600 bg-amber-50',
    },
    {
      title: 'Tuberculosis',
      desc: 'Comprehensive TB diagnosis & DOTS management',
      slug: 'tuberculosis',
      icon: ShieldCheck,
      color: 'text-emerald-600 bg-emerald-50',
    },
    {
      title: 'Pleural Disease',
      desc: 'Effusion, pleurisy & diagnostic thoracentesis',
      slug: 'pleural-disease',
      icon: Microscope,
      color: 'text-purple-600 bg-purple-50',
    },
  ];

  // Active state determination
  const isHomeActive = activeRoute === 'home';
  const isSleepActive = activeRoute === 'condition' && selectedConditionSlug === 'sleep-apnea';
  const isInterventionalActive = activeRoute === 'condition' && selectedConditionSlug === 'bronchoscopy';
  const isLungConditionActive =
    activeRoute === 'condition' &&
    selectedConditionSlug !== 'sleep-apnea' &&
    selectedConditionSlug !== 'bronchoscopy';
  const isBlogsActive = activeRoute === 'blogs' || activeRoute === 'blog-detail';
  const isContactActive = activeRoute === 'contact';

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-xl shadow-xs shadow-slate-900/5 border-b border-slate-200/80 py-2.5 sm:py-3'
          : 'bg-white/80 backdrop-blur-md border-b border-slate-200/50 py-3.5 sm:py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-2 lg:gap-4">
          
          {/* ========================================================= */}
          {/* 1. BRAND AREA (Dr. Kritarth + DM Pulmonology)            */}
          {/* ========================================================= */}
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="shrink-0"
          >
            <button
              id="brand-logo-btn"
              onClick={() => handleNavClick('home')}
              className="flex items-center gap-3 text-left group focus:outline-none cursor-pointer"
            >
              {/* Premium Logo Icon Container */}
              <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-teal-600 via-teal-700 to-cyan-700 flex items-center justify-center text-white shadow-md shadow-teal-700/20 group-hover:shadow-teal-700/35 group-hover:scale-105 transition-all duration-200">
                <Wind className="w-5 h-5 text-white stroke-[2.2] group-hover:rotate-6 transition-transform duration-300" />
                {/* Subtle sheen highlight */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-transparent via-white/10 to-white/25 pointer-events-none" />
              </div>

              {/* Doctor Details Hierarchy */}
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-heading font-extrabold text-lg sm:text-xl text-slate-900 tracking-tight leading-tight group-hover:text-teal-800 transition-colors">
                    {settings.doctorName || 'Dr. Kritarth'}
                  </span>
                  
                  {/* Refined DM Pulmonology Pill Badge */}
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-50 text-teal-800 border border-teal-200/80 tracking-wide uppercase shadow-2xs">
                    <Sparkles className="w-2.5 h-2.5 text-teal-600" />
                    <span>DM Pulmonology</span>
                  </span>
                </div>

                <p className="text-[11px] sm:text-xs text-slate-500 font-medium truncate max-w-[190px] sm:max-w-none tracking-normal leading-tight mt-0.5">
                  <span>{settings.doctorDesignation || 'Consultant – Pulmonary & Sleep Medicine'}</span>
                  <span className="text-slate-300 mx-1">•</span>
                  <span className="text-slate-600 font-semibold">{settings.primaryHospital}</span>
                </p>
              </div>
            </button>
          </motion.div>

          {/* ========================================================= */}
          {/* 2. DESKTOP NAVIGATION LINKS                               */}
          {/* ========================================================= */}
          <motion.nav
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="hidden lg:flex items-center gap-0.5 xl:gap-1 text-xs xl:text-sm font-medium text-slate-700"
          >
            {/* Home Link */}
            <button
              id="nav-home"
              onClick={() => handleNavClick('home')}
              className={`relative px-3 py-1.5 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                isHomeActive
                  ? 'text-teal-800 font-semibold bg-teal-50/90 shadow-2xs'
                  : 'text-slate-700 hover:text-teal-800 hover:bg-teal-50/60'
              }`}
            >
              <span>Home</span>
              {isHomeActive && (
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-teal-600" />
              )}
            </button>

            {/* About Link */}
            <button
              id="nav-about"
              onClick={() => {
                if (activeRoute !== 'home') {
                  navigate('home');
                  setTimeout(() => {
                    document.getElementById('about-section')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                } else {
                  document.getElementById('about-section')?.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="px-3 py-1.5 rounded-full text-slate-700 hover:text-teal-800 hover:bg-teal-50/60 transition-all duration-200 cursor-pointer whitespace-nowrap"
            >
              About
            </button>

            {/* Lung Conditions Dropdown Trigger */}
            <div
              className="relative"
              onMouseEnter={handleMouseEnterDropdown}
              onMouseLeave={handleMouseLeaveDropdown}
            >
              <button
                id="nav-conditions-dropdown"
                onClick={() => setConditionsDropdownOpen(!conditionsDropdownOpen)}
                className={`relative px-3 py-1.5 rounded-full transition-all duration-200 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap ${
                  isLungConditionActive || conditionsDropdownOpen
                    ? 'text-teal-800 font-semibold bg-teal-50/90 shadow-2xs'
                    : 'text-slate-700 hover:text-teal-800 hover:bg-teal-50/60'
                }`}
                aria-haspopup="true"
                aria-expanded={conditionsDropdownOpen}
              >
                <span>Lung Conditions</span>
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${
                    conditionsDropdownOpen ? 'rotate-180 text-teal-700' : 'text-slate-400'
                  }`}
                />
                {isLungConditionActive && (
                  <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-teal-600" />
                )}
              </button>

              {/* Dropdown Panel with Motion */}
              <AnimatePresence>
                {conditionsDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 6, scale: 0.98 }}
                    transition={{ duration: 0.18, ease: 'easeOut' }}
                    className="absolute top-full left-0 mt-2 w-80 bg-white rounded-2xl shadow-xl shadow-slate-900/10 border border-slate-100 p-2 z-50"
                  >
                    <div className="px-3 py-2 border-b border-slate-100 flex items-center justify-between">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                        Respiratory Conditions
                      </span>
                      <span className="text-[10px] font-semibold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-md">
                        Super-Specialty Care
                      </span>
                    </div>

                    <div className="py-1 space-y-0.5 max-h-[380px] overflow-y-auto">
                      {lungConditionsList.map((item) => {
                        const IconComponent = item.icon;
                        const isCurrent =
                          activeRoute === 'condition' && selectedConditionSlug === item.slug;
                        return (
                          <button
                            key={item.slug}
                            id={`nav-dropdown-item-${item.slug}`}
                            onClick={() => handleNavClick('condition', item.slug)}
                            className={`w-full text-left px-3 py-2 rounded-xl transition-all duration-150 flex items-start gap-2.5 group cursor-pointer ${
                              isCurrent
                                ? 'bg-teal-50/90 text-teal-900 font-semibold'
                                : 'hover:bg-teal-50/60 text-slate-700'
                            }`}
                          >
                            <div
                              className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 transition-transform group-hover:scale-110 ${item.color}`}
                            >
                              <IconComponent className="w-3.5 h-3.5" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-xs font-semibold text-slate-900 group-hover:text-teal-800 transition-colors flex items-center justify-between">
                                <span>{item.title}</span>
                                <ArrowRight className="w-3 h-3 text-slate-300 opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 text-teal-600 transition-all" />
                              </div>
                              <p className="text-[11px] text-slate-500 font-normal leading-tight truncate">
                                {item.desc}
                              </p>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* Dropdown footer quick link */}
                    <div className="pt-2 mt-1 border-t border-slate-100 px-2">
                      <button
                        onClick={() => {
                          setConditionsDropdownOpen(false);
                          if (activeRoute !== 'home') {
                            navigate('home');
                            setTimeout(() => {
                              document.getElementById('specialities-section')?.scrollIntoView({ behavior: 'smooth' });
                            }, 100);
                          } else {
                            document.getElementById('specialities-section')?.scrollIntoView({ behavior: 'smooth' });
                          }
                        }}
                        className="w-full py-1.5 px-3 rounded-lg text-center text-xs font-semibold text-teal-700 bg-teal-50/50 hover:bg-teal-100/70 transition-colors flex items-center justify-center gap-1.5"
                      >
                        <span>View All Clinical Specialties</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Sleep Medicine */}
            <button
              id="nav-sleep-medicine"
              onClick={() => handleNavClick('condition', 'sleep-apnea')}
              className={`relative px-3 py-1.5 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                isSleepActive
                  ? 'text-teal-800 font-semibold bg-teal-50/90 shadow-2xs'
                  : 'text-slate-700 hover:text-teal-800 hover:bg-teal-50/60'
              }`}
            >
              <span>Sleep Medicine</span>
              {isSleepActive && (
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-teal-600" />
              )}
            </button>

            {/* Interventional Pulmonology */}
            <button
              id="nav-interventional"
              onClick={() => handleNavClick('condition', 'bronchoscopy')}
              className={`relative px-3 py-1.5 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                isInterventionalActive
                  ? 'text-teal-800 font-semibold bg-teal-50/90 shadow-2xs'
                  : 'text-slate-700 hover:text-teal-800 hover:bg-teal-50/60'
              }`}
            >
              <span>Interventional Pulmonology</span>
              {isInterventionalActive && (
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-teal-600" />
              )}
            </button>

            {/* Diagnostics */}
            <button
              id="nav-diagnostics"
              onClick={() => {
                if (activeRoute !== 'home') {
                  navigate('home');
                  setTimeout(() => {
                    document.getElementById('diagnostics-section')?.scrollIntoView({ behavior: 'smooth' });
                  }, 100);
                } else {
                  document.getElementById('diagnostics-section')?.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="px-3 py-1.5 rounded-full text-slate-700 hover:text-teal-800 hover:bg-teal-50/60 transition-all duration-200 cursor-pointer whitespace-nowrap"
            >
              Diagnostics
            </button>

            {/* Blogs */}
            <button
              id="nav-blogs"
              onClick={() => handleNavClick('blogs')}
              className={`relative px-3 py-1.5 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                isBlogsActive
                  ? 'text-teal-800 font-semibold bg-teal-50/90 shadow-2xs'
                  : 'text-slate-700 hover:text-teal-800 hover:bg-teal-50/60'
              }`}
            >
              <span>Blogs</span>
              {isBlogsActive && (
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-teal-600" />
              )}
            </button>

            {/* Contact */}
            <button
              id="nav-contact"
              onClick={() => handleNavClick('contact')}
              className={`relative px-3 py-1.5 rounded-full transition-all duration-200 cursor-pointer whitespace-nowrap ${
                isContactActive
                  ? 'text-teal-800 font-semibold bg-teal-50/90 shadow-2xs'
                  : 'text-slate-700 hover:text-teal-800 hover:bg-teal-50/60'
              }`}
            >
              <span>Contact</span>
              {isContactActive && (
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-teal-600" />
              )}
            </button>
          </motion.nav>

          {/* ========================================================= */}
          {/* 3. RIGHT CTAS (Call Button + Book Appointment Button)     */}
          {/* ========================================================= */}
          <div className="hidden sm:flex items-center gap-2 xl:gap-3 shrink-0">
            {/* Call Button (Secondary Action) */}
            <motion.a
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.2 }}
              id="header-call-btn"
              href={`tel:${settings.phonePrimary}`}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white/90 hover:bg-teal-50/70 hover:text-teal-800 border border-slate-200/90 hover:border-teal-300 rounded-full shadow-2xs hover:shadow-xs hover:-translate-y-0.5 transition-all duration-200 group cursor-pointer"
              title="Direct Clinic Reception Line"
            >
              <Phone className="w-3.5 h-3.5 text-teal-600 group-hover:rotate-12 transition-transform duration-200" />
              <span>Call</span>
            </motion.a>

            {/* Book Appointment Button (Primary Action) */}
            <motion.button
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.28 }}
              id="header-book-appointment-btn"
              onClick={() => openAppointmentModal()}
              className="relative overflow-hidden inline-flex items-center gap-2 px-4.5 py-2 sm:px-5 sm:py-2.5 text-xs font-heading font-bold text-white bg-gradient-to-r from-teal-700 via-teal-600 to-cyan-600 hover:from-teal-800 hover:to-cyan-700 rounded-xl sm:rounded-2xl shadow-md shadow-teal-700/20 hover:shadow-lg hover:shadow-teal-700/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 group cursor-pointer"
            >
              {/* Subtle shining light sweep */}
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent pointer-events-none" />
              <Calendar className="w-3.5 h-3.5 text-teal-100 group-hover:scale-110 transition-transform duration-200" />
              <span className="tracking-wide">Book Appointment</span>
            </motion.button>
          </div>

          {/* ========================================================= */}
          {/* 4. MOBILE NAVBAR CONTROLS                                 */}
          {/* ========================================================= */}
          <div className="flex lg:hidden items-center gap-2">
            {/* Quick Book Button on Mobile Header */}
            <button
              id="mobile-header-book-btn"
              onClick={() => openAppointmentModal()}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-heading font-bold text-white bg-gradient-to-r from-teal-600 to-cyan-600 rounded-xl shadow-xs"
            >
              <Calendar className="w-3 h-3 text-teal-100" />
              <span>Book</span>
            </button>

            {/* Hamburger Toggle Button */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 hover:text-teal-800 rounded-xl hover:bg-slate-100 focus:outline-none transition-colors"
              aria-label="Toggle Navigation Menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 text-slate-800" />
              ) : (
                <Menu className="w-6 h-6 text-slate-800" />
              )}
            </button>
          </div>

        </div>
      </div>

      {/* ========================================================= */}
      {/* 5. MOBILE MENU SLIDE-DOWN DRAWER                          */}
      {/* ========================================================= */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="lg:hidden bg-white/95 backdrop-blur-xl border-b border-slate-200 shadow-2xl overflow-hidden"
          >
            <div className="max-w-7xl mx-auto px-5 py-6 max-h-[80vh] overflow-y-auto space-y-4">
              
              {/* Main Links */}
              <div className="flex flex-col space-y-1 text-sm font-semibold text-slate-800">
                {/* Home */}
                <button
                  onClick={() => handleNavClick('home')}
                  className={`text-left px-3 py-2.5 rounded-xl transition-colors ${
                    isHomeActive ? 'bg-teal-50 text-teal-800 font-bold' : 'hover:bg-slate-50'
                  }`}
                >
                  Home
                </button>

                {/* About */}
                <button
                  onClick={() => {
                    navigate('home');
                    setMobileMenuOpen(false);
                    setTimeout(() => {
                      document.getElementById('about-section')?.scrollIntoView({ behavior: 'smooth' });
                    }, 150);
                  }}
                  className="text-left px-3 py-2.5 rounded-xl hover:bg-slate-50 transition-colors"
                >
                  About Dr. Kritarth
                </button>

                {/* Lung Conditions Accordion */}
                <div className="border border-slate-100 rounded-2xl p-1 bg-slate-50/50">
                  <button
                    onClick={() => setMobileConditionsExpanded(!mobileConditionsExpanded)}
                    className="w-full flex items-center justify-between px-3 py-2.5 text-left text-sm font-bold text-slate-800 hover:text-teal-800"
                  >
                    <span className="flex items-center gap-2">
                      <Wind className="w-4 h-4 text-teal-600" />
                      <span>Lung Conditions</span>
                    </span>
                    <ChevronDown
                      className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                        mobileConditionsExpanded ? 'rotate-180 text-teal-600' : ''
                      }`}
                    />
                  </button>

                  <AnimatePresence>
                    {mobileConditionsExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden space-y-1 pt-1 pb-2 px-1"
                      >
                        {lungConditionsList.map((item) => {
                          const IconComp = item.icon;
                          return (
                            <button
                              key={item.slug}
                              onClick={() => handleNavClick('condition', item.slug)}
                              className="w-full text-left px-3 py-2 rounded-xl text-xs font-medium text-slate-700 hover:bg-white hover:text-teal-800 flex items-center gap-2.5 transition-colors"
                            >
                              <div className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 ${item.color}`}>
                                <IconComp className="w-3 h-3" />
                              </div>
                              <span className="font-semibold">{item.title}</span>
                            </button>
                          );
                        })}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Sleep Medicine */}
                <button
                  onClick={() => handleNavClick('condition', 'sleep-apnea')}
                  className={`text-left px-3 py-2.5 rounded-xl transition-colors ${
                    isSleepActive ? 'bg-teal-50 text-teal-800 font-bold' : 'hover:bg-slate-50'
                  }`}
                >
                  Sleep Medicine
                </button>

                {/* Interventional Pulmonology */}
                <button
                  onClick={() => handleNavClick('condition', 'bronchoscopy')}
                  className={`text-left px-3 py-2.5 rounded-xl transition-colors ${
                    isInterventionalActive ? 'bg-teal-50 text-teal-800 font-bold' : 'hover:bg-slate-50'
                  }`}
                >
                  Interventional Pulmonology
                </button>

                {/* Diagnostics */}
                <button
                  onClick={() => {
                    navigate('home');
                    setMobileMenuOpen(false);
                    setTimeout(() => {
                      document.getElementById('diagnostics-section')?.scrollIntoView({ behavior: 'smooth' });
                    }, 150);
                  }}
                  className="text-left px-3 py-2.5 rounded-xl hover:bg-slate-50 transition-colors"
                >
                  Diagnostics
                </button>

                {/* Blogs */}
                <button
                  onClick={() => handleNavClick('blogs')}
                  className={`text-left px-3 py-2.5 rounded-xl transition-colors ${
                    isBlogsActive ? 'bg-teal-50 text-teal-800 font-bold' : 'hover:bg-slate-50'
                  }`}
                >
                  Blogs
                </button>

                {/* Contact */}
                <button
                  onClick={() => handleNavClick('contact')}
                  className={`text-left px-3 py-2.5 rounded-xl transition-colors ${
                    isContactActive ? 'bg-teal-50 text-teal-800 font-bold' : 'hover:bg-slate-50'
                  }`}
                >
                  Contact
                </button>
              </div>

              {/* Bottom Full-Width CTAs */}
              <div className="pt-4 border-t border-slate-100 flex flex-col gap-2.5">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    openAppointmentModal();
                  }}
                  className="w-full py-3 text-center text-sm font-heading font-bold text-white bg-gradient-to-r from-teal-700 via-teal-600 to-cyan-600 rounded-xl shadow-md shadow-teal-700/20 flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4 h-4 text-teal-100" />
                  <span>Book Appointment</span>
                </button>

                <a
                  href={`tel:${settings.phonePrimary}`}
                  className="w-full py-3 text-center text-sm font-heading font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200/80 rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  <Phone className="w-4 h-4 text-teal-600" />
                  <span>Call Now ({settings.phonePrimary})</span>
                </a>
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
