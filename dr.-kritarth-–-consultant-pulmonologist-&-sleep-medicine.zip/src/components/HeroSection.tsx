import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import pulmonologyClinicDoctor from '../assets/images/pulmonology_clinic_doctor.webp';
import {
  Calendar,
  Phone,
  ArrowRight,
  ShieldCheck,
  MapPin,
  MessageSquare,
  GraduationCap,
  Stethoscope
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { settings, openAppointmentModal } = useApp();

  const heroImage = settings?.heroImageUrl || pulmonologyClinicDoctor;

  const cleanWhatsapp = (settings.whatsappNumber || "+919876543210").replace(/[^0-9]/g, '');
  const whatsappPreFill = encodeURIComponent(
    "Hello Dr. Kritarth, I would like to schedule a consultation regarding respiratory / lung care."
  );

  return (
    <section
      id="home-hero-section"
      className="relative min-h-[650px] lg:min-h-[85vh] flex items-center overflow-hidden bg-[#F7FCFD] pt-28 pb-16 sm:pt-32 sm:pb-20 lg:py-24"
      aria-label="Clinical Pulmonology Hero - Dr. Kritarth"
    >
      {/* ========================================================= */}
      {/* FULL-WIDTH HERO VISUAL BACKGROUND LAYER                   */}
      {/* Uses local pulmonology_clinic_doctor.webp asset           */}
      {/* ========================================================= */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none">
        {/* Main Hero Doctor & Clinic Image with Subtle 1.02 -> 1 Entrance Scale */}
        <motion.img
          key={heroImage}
          src={heroImage}
          alt={`${settings.doctorName || "Dr. Kritarth"} – Consultant Pulmonologist & Sleep Specialist`}
          initial={{ scale: 1.02, opacity: 0.85 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
          className="w-full h-full object-cover object-[68%_center] sm:object-[70%_center] lg:object-[center_right] will-change-transform"
        />

        {/* Desktop Left-Side Overlay Gradient for Crisp Text Contrast */}
        {/* Exactly matching specified curve: 98% -> 88% -> 30% -> 0% */}
        <div
          className="absolute inset-0 hidden lg:block"
          style={{
            background:
              'linear-gradient(90deg, rgba(247,252,253,0.98) 0%, rgba(247,252,253,0.88) 30%, rgba(247,252,253,0.30) 52%, rgba(247,252,253,0) 70%)'
          }}
        />

        {/* Tablet Gradient Overlay (Left to Right with Smooth Transition) */}
        <div
          className="absolute inset-0 hidden sm:block lg:hidden"
          style={{
            background:
              'linear-gradient(90deg, rgba(247,252,253,0.98) 0%, rgba(247,252,253,0.90) 42%, rgba(247,252,253,0.40) 68%, rgba(247,252,253,0.15) 100%)'
          }}
        />

        {/* Mobile Vertical Gradient: Top Content Contrast + Preserves Doctor Visual */}
        <div
          className="absolute inset-0 sm:hidden"
          style={{
            background:
              'linear-gradient(180deg, rgba(247,252,253,0.98) 0%, rgba(247,252,253,0.92) 55%, rgba(247,252,253,0.65) 80%, rgba(247,252,253,0.90) 100%)'
          }}
        />

        {/* Faint ambient atmospheric contour in the background */}
        <svg
          className="absolute inset-0 w-full h-full opacity-25 text-[#125B62]"
          viewBox="0 0 1440 800"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
        >
          <path
            d="M-50 360 C 280 260, 580 440, 920 320"
            stroke="currentColor"
            strokeWidth="1.2"
            strokeDasharray="4 8"
          />
        </svg>
      </div>

      {/* ========================================================= */}
      {/* HERO CONTENT: Strictly positioned on LEFT clean area      */}
      {/* ========================================================= */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="max-w-xl lg:max-w-2xl text-left">

          {/* 1. Specialty Badge */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/95 border border-[#125B62]/20 text-[#125B62] text-xs font-bold tracking-[0.14em] uppercase mb-5 shadow-2xs backdrop-blur-xs font-heading"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#125B62]" />
            </span>
            <span>{settings.heroBadge || "PULMONOLOGY • RESPIRATORY • SLEEP MEDICINE"}</span>
          </motion.div>

          {/* 2. Main Headline: Staggered Line Entrance */}
          <h1 className="text-4xl sm:text-5xl lg:text-[3.65rem] font-heading font-extrabold text-[#102126] tracking-tight leading-[1.08] mb-5">
            <motion.span
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="block"
            >
              Breathe Better.
            </motion.span>

            <motion.span
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="block relative mt-0.5"
            >
              <span className="relative inline-block text-transparent bg-clip-text bg-gradient-to-r from-[#125B62] via-[#1B7D7A] to-[#125B62]">
                Sleep Better.
              </span>
              <span className="absolute -bottom-1 left-0 w-32 sm:w-44 h-1 rounded-full bg-gradient-to-r from-[#125B62]/60 via-[#A8C7BE]/80 to-transparent pointer-events-none" />
            </motion.span>

            <motion.span
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.34, ease: [0.16, 1, 0.3, 1] }}
              className="block mt-0.5"
            >
              Live Better.
            </motion.span>
          </h1>

          {/* 3. Short Description */}
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.44, ease: [0.16, 1, 0.3, 1] }}
            className="text-base sm:text-lg text-[#5F7073] font-normal leading-relaxed max-w-lg mb-6"
          >
            {settings.heroSubtitle ||
              "Specialized clinical care for complex lung diseases, respiratory problems, sleep-related breathing disorders, and advanced interventional pulmonology."}
          </motion.p>

          {/* 4. Doctor Credential Capsule (Refined, Crisp Frosted Glass) */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.54, ease: [0.16, 1, 0.3, 1] }}
            className="p-4 sm:p-5 rounded-2xl bg-white/90 backdrop-blur-md border border-[#125B62]/15 shadow-[0_10px_25px_rgba(7,27,36,0.04)] mb-7 max-w-lg"
          >
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-2">
                <span className="font-heading font-bold text-[#102126] text-base sm:text-lg tracking-tight">
                  {settings.doctorName || "Dr. Kritarth"}
                </span>
                <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#125B62]/10 text-[#125B62] border border-[#125B62]/20 text-[11px] font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#125B62]" />
                  <span>Verified Specialist</span>
                </div>
              </div>
              <span className="text-[11px] font-semibold text-[#65777A] flex items-center gap-1">
                <Stethoscope className="w-3.5 h-3.5 text-[#125B62]" />
                <span>OPD & Inpatient Care</span>
              </span>
            </div>

            <p className="text-xs sm:text-sm font-semibold text-[#125B62] mb-2.5">
              {settings.doctorDesignation || "Consultant – Pulmonary & Sleep Medicine"}
            </p>

            <div className="bg-[#F5F7F4] rounded-xl p-2.5 border border-[#E5EAE7] flex items-center gap-2.5 text-xs text-[#102126]">
              <div className="w-6 h-6 rounded-lg bg-[#125B62]/10 text-[#125B62] flex items-center justify-center shrink-0">
                <GraduationCap className="w-3.5 h-3.5" />
              </div>
              <div className="truncate text-xs font-medium">
                <span className="font-bold text-[#102126]">DM Pulmonology (PGIMER Chandigarh)</span>
                <span className="text-[#A8C7BE] mx-1.5">•</span>
                <span className="text-[#5F7073]">MD</span>
                <span className="text-[#A8C7BE] mx-1.5">•</span>
                <span className="text-[#5F7073]">MBBS</span>
              </div>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-100 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#5F7073] font-medium">
              <span className="flex items-center gap-1 text-[#102126] font-semibold">
                <MapPin className="w-3.5 h-3.5 text-[#125B62] shrink-0" />
                {settings.primaryHospital || "Livasa Hospital Mohali"}
              </span>
              <span className="text-[#A8C7BE]">•</span>
              <span>Ex-PGIMER Chandigarh</span>
            </div>
          </motion.div>

          {/* 5. Action Controls: Book Appointment + Call Now */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.65, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-wrap items-center gap-3.5 mb-5 w-full sm:w-auto"
          >
            {/* Primary CTA: Book Appointment */}
            <button
              onClick={() => openAppointmentModal()}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl text-sm font-heading font-bold text-white bg-gradient-to-r from-[#125B62] via-[#1B7D7A] to-[#125B62] hover:opacity-95 shadow-md shadow-[#125B62]/20 hover:shadow-lg hover:shadow-[#125B62]/30 transition-all cursor-pointer hover:-translate-y-0.5"
            >
              <Calendar className="w-4 h-4 text-teal-100" />
              <span>Book Appointment</span>
            </button>

            {/* Secondary CTA: Call Now */}
            <a
              href={`tel:${settings.phonePrimary || "+919876543210"}`}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl text-sm font-heading font-semibold text-[#102126] bg-white border border-[#D5E0DC] hover:border-[#125B62]/40 hover:bg-[#F5F7F4] shadow-2xs transition-all cursor-pointer hover:-translate-y-0.5"
            >
              <Phone className="w-4 h-4 text-[#125B62]" />
              <span>Call Now</span>
            </a>

            {/* Direct WhatsApp Quick Chat */}
            <a
              href={`https://wa.me/${cleanWhatsapp}?text=${whatsappPreFill}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl text-xs font-heading font-semibold text-emerald-800 bg-emerald-50/90 border border-emerald-200/90 hover:bg-emerald-100/90 shadow-2xs transition-all cursor-pointer"
            >
              <MessageSquare className="w-4 h-4 text-emerald-600" />
              <span>WhatsApp Inquiry</span>
            </a>
          </motion.div>

          {/* Explore Link */}
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.78 }}
            onClick={() => {
              document.getElementById('specialities-section')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#125B62] hover:text-[#0c4045] group cursor-pointer transition-colors"
          >
            <span>Explore Lung Conditions &amp; Clinical Services</span>
            <ArrowRight className="w-4 h-4 text-[#125B62] group-hover:translate-x-1 transition-transform" />
          </motion.button>

        </div>
      </div>
    </section>
  );
};
